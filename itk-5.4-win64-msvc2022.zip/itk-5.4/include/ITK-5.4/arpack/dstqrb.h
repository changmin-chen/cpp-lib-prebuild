extern int v3p_netlib_dstqrb_(
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *d__,
  v3p_netlib_doublereal *e,
  v3p_netlib_doublereal *z__,
  v3p_netlib_doublereal *work,
  v3p_netlib_integer *info
  );
