extern int v3p_netlib_dsaitr_(
  v3p_netlib_integer *ido,
  char *bmat,
  v3p_netlib_integer *n,
  v3p_netlib_integer *k,
  v3p_netlib_integer *np,
  v3p_netlib_integer *mode,
  v3p_netlib_doublereal *resid,
  v3p_netlib_doublereal *rnorm,
  v3p_netlib_doublereal *v,
  v3p_netlib_integer *ldv,
  v3p_netlib_doublereal *h__,
  v3p_netlib_integer *ldh,
  v3p_netlib_integer *ipntr,
  v3p_netlib_doublereal *workd,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen bmat_len
  );
