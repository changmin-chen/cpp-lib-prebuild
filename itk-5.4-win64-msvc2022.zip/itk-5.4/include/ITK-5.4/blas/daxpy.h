extern int v3p_netlib_daxpy_(
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *da,
  v3p_netlib_doublereal *dx,
  v3p_netlib_integer *incx,
  v3p_netlib_doublereal *dy,
  v3p_netlib_integer *incy
  );
