extern int v3p_netlib_xerbla_(
  char *srname,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen srname_len
  );
