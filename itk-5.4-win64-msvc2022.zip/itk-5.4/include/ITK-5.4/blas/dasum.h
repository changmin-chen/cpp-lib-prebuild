extern v3p_netlib_doublereal v3p_netlib_dasum_(
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *dx,
  v3p_netlib_integer *incx
  );
