// © Kitware, Inc. See license.md for details.
#ifndef token_Options_h
#define token_Options_h

#define token_NAMESPACE vtktoken
#define token_BEGIN_NAMESPACE namespace vtktoken {
#define token_CLOSE_NAMESPACE } /* namespace vtktoken */

#endif // token_Options_h
