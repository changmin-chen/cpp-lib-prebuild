// SPDX-FileCopyrightText: Copyright (c) 2003 Matt Turek
// SPDX-License-Identifier: BSD-4-Clause

#ifndef __DICOMCMakeConfig_h_
#define __DICOMCMakeConfig_h_

#define DICOM_DLL
/* #undef DICOM_STATIC */

#include <vtksys/Configure.hxx>

#endif
