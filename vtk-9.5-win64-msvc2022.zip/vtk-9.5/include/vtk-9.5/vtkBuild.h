// SPDX-FileCopyrightText: Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
// SPDX-License-Identifier: BSD-3-Clause
#ifndef vtkBuild_h
#define vtkBuild_h

/* Whether we are building shared libraries.  */
#define VTK_BUILD_SHARED_LIBS

#endif
